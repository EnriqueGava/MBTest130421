const mariadb = require("mariadb");

const pool = mariadb.createPool({
    host: "localhost",
    user: "root",
    password: "1234",
    database: "mb",
    port: "3606"
});

async function getConn() {
    const conn = await pool.getConnection();
    return conn;
}

module.exports.getConn = getConn;