const express = require("express");
const cors = require("cors");
const body = require("body-parser");
const bodyParser = require("body-parser");
const morgan = require("morgan");
const session = require("express-session");
const jwt = require("jsonwebtoken");
const axios = require("axios");

const app = express();

require("dotenv").config();
app.set('port',process.env.PORT || 4000);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(cors());
app.use(session({
    secret: "qwerty",
    resave: true,
    saveUninitialized: true,
    cookie: {
        secure: true,
        httpOnly: true,
        expires: 120
    },
    
}));


//Middlewares

app.use(morgan("dev"));

//DB
const db = require("./db");



//Routes

app.get("/", (req,res) => {
    req.session.loggedin = true;
    res.send("ok")
});



app.post("/home", (req,res) => {
    console.log(req.body)
    axios.post("http://localhost:5000/auth", {email: "ricardo@metrobus.com.mx", password: "1234"})
    .then(response => {
        res.send(response.data)
    })
    .catch(err => {
        console.log('Contraseña y Usuarios no validos , ' + err)
      })
});


app.post("/auth", async (req,res) => {
    console.log(req.session.loggedin);
    let email = req.body.email;
    let pass = req.body.password;
    console.log(email + " " + pass);

    try
    {
    const conn  = db.getConn();
    const rows =  (await conn).query(`select * from persona where User_ID = '${email}';`)
    .then(rows => {
        if(rows.length>0 && rows[0].Pwd == pass)
        {
            let token = jwt.sign(email, 'secreto')
            res.send(token)
            console.log("logeado");
            
            //res.redirect("/Jud/levantamientos");
        }
        else
            res.status(200).json({'data': 'sin logged in'})
    });
    
    }
    catch(err)
    {
        console.log(err)
    }
    
   
    

});

app.get("/users", async (req, res) => {
    try
    {
    const conn  = db.getConn();
    const user = [{}];
    const rows =  (await conn).query("select * from persona;")
    .then(rows => console.log(rows[0].Nombre))
    
    
    
    }
    catch(err)
    {
        console.log(err)
    }

    
});


//listen 
const port = app.get('port');
app.listen(port, () => {
    console.log(`corriendo en el puerto ${port}`);
});