import React from 'react';
import { ThemeProvider } from '@material-ui/core';
import theme from './theme';

import Container from './componentes/SideBar/Container';
import ContainerL from './componentes/SideBar/SideBarL/ContainerL'
import ContainerM from './componentes/SideBar/SideBarM/ContainerM'
import ContainerCu from './componentes/SideBar/SideBarCu/ContainerCu'
import Routes from './Routes';

function App(props) {

  console.log(props.role)
  if(props.role == 1)
  return (
    <ThemeProvider theme={theme}>
      <Container/>

    </ThemeProvider>
  );
  else if(props.role == 2)
    return <ContainerM/>
  else
    
  
  return (
    <ThemeProvider theme={theme}>
      {/*<Container/>*/}
     
      {/*<ContainerM/>*/}

      

      <Routes/>

      {/*<Routes_C/>*/}

      
      
    </ThemeProvider>
  );
}

export default App;
