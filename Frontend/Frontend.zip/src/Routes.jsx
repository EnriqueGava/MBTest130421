import React from 'react'
import {BrowserRouter as Router,
Switch,
Route,
Link,
withRouter} from 'react-router-dom'
import Levantamiento from './componentes/paginas/Levantamiento';
import LevantamientoCu from './componentes/paginas/Campo/LevantamientosC';
import SolicitudT from './componentes/paginas/SolicitudT';
import LevantamientoD from './componentes/Dialogs/LevantamientoD';
import SolicitudTD from './componentes/Dialogs/SolicitudTD';
import LevantamientoDC from './componentes/Dialogs/Campo/LevantamientoDC';

import LevantamientoNue from './componentes/paginas/Campo/LevantamientoNue';
import LevantamientosCu from './componentes/paginas/Cuadrilla/LevantamientosCu';

import LevantamientoNueD from './componentes/Dialogs/Campo/LevantamientoNueD';
import SolicitudAD from './componentes/Dialogs/SolicitudAD';
import Almacen from './componentes/paginas/Mantenimiento/Almacen';
import STrabajo from './componentes/paginas/Mantenimiento/S_Trabajo'
import MaLevant from './componentes/paginas/Mantenimiento/Lev_Mant'
import StatusT from './componentes/paginas/Mantenimiento/Status_Trabajo'
import LevantamientoCD from './componentes/Dialogs/Campo/LevantamientoCD';
import Login from './componentes/paginas/Login/Login'
import Signup from './componentes/paginas/Login/Signup'
import RecuperarC from './componentes/paginas/Login/RecuperarC'

const Routes = () => {
    return ( 
        
            <div>
            <hr/>
                <Route path="/" component={Login} exact={true} />
                <Route path="/Jud/levantamientos" component={Levantamiento} exact/>
                <Route path="/Jud/levantamientos/Dialog" component={LevantamientoD} exact/>
                <Route path="/Jud/solicitud_trabajo" component={SolicitudT} exact/>
                <Route path="/Jud/solicitud_trabajo/Dialog" component={SolicitudTD} exact/>
                <Route path="/Jud/solicitud_almacen/Dialog" component={SolicitudAD}/>
                <Route path="/Campo/levantamientos" component={LevantamientoCu} exact/>
                <Route path="/Cuadrilla/levantamientos_cu" component={LevantamientosCu} exact/>
                <Route path="/Campo/levantamientos/Dialog" component={LevantamientoCD} exact/>
                <Route path="/Campo/new_levantamientos" component={LevantamientoNue} exact/>
                <Route path="/Campo/new_levantamientos/Dialog" component={LevantamientoNueD} exact/>
                <Route path="/Mantenimiento/MaLevantamiento" component={MaLevant} exact/>
                <Route path="/Mantenimiento/Almacen" component={Almacen} exact/>
                <Route path="/Mantenimiento/STrabajo" component={STrabajo} exact/>
                <Route path="/Mantenimiento/Status_T" component={StatusT} exact/>
                
                <Route path="/RecuperarC" component={RecuperarC} exact/>
                <Route path="/SignUp" component={Signup} exact/>
                
            </div>
     );
}
 
export default Routes;
