import React from 'react'
import { Avatar, Typography, makeStyles } from '@material-ui/core';

const Perfil = () => {

  const estilos = makeStyles(theme => ({
    root: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      minHeight: 'fit-content'
    },
    avatar: {
      width: 130,
      height: 130
    },
    name: {
      marginTop: theme.spacing(1)
    },
    offset: theme.mixins.toolbar
  }));
  const classes = estilos();

  return (
    <div className={classes.root}>
      <Avatar
        alt="Person"
        className={classes.avatar}
        src="/images/avatars/avatar_3.png"
      />
      <Typography
        className={classes.name}
        variant="h4"
        style={{ color: '#FFFFFF' }}
      >
        Kevin
      </Typography>
      <Typography variant="body1" style={{ color: '#f4f6f8' }}>Personal de Campo</Typography>
    </div>
  );
}

export default Perfil;
