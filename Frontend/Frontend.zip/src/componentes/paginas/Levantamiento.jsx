import React from 'react'
import { withStyles, makeStyles, fade } from '@material-ui/core/styles';
import { Table, TablePagination, TextField, Icon, Container } from '@material-ui/core';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import { green, purple, red, yellow } from '@material-ui/core/colors';
import { Grid, Box, InputBase } from '@material-ui/core/';
import { withRouter } from 'react-router-dom';
import SearchInput from './../SearchInput';
import { Link } from 'react-router-dom'
import LevantamientoD from './../Dialogs/LevantamientoD';
import { CheckCircle, Cancel, HourglassFull } from '@material-ui/icons';

const Levantamiento = () => {

    const [page, setPage] = React.useState(2);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const useStyles = makeStyles(theme => ({
        table: {
            minWidth: 50
        },
        margin: {
            margin: theme.spacing(1),
        },
        Box: {
            backgroundColor: theme.palette.grey[200],
            width: 300,
            marginBottom: 7,

        },
        Font: {
            marginBottom: 2,
        },
        root: {

        }

    }));

    const [abrir, setAbrir] = React.useState(false)
    const AbrirD = () => {
        setAbrir(!abrir)
    };

    const classes = useStyles();

    return (
        <Container>
            <SearchInput
                placeholder="Buscar"
            />
            <TableContainer component={Paper}>
                <Grid item xs={12}>
                    <Box mr={0}>
                        <Table stickyHeader aria-label="sticky table">
                            <TableHead>
                                <TableRow>
                                    <TableCell align="center">Numero de levantamiento</TableCell>
                                    <TableCell align="center">Fecha</TableCell>
                                    <TableCell align="center">Estado</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                <TableRow hover>
                                    <TableCell align="center" component="th" scope="row" >

                                        <Button onClick={AbrirD}>1300</Button>
                                    </TableCell>
                                    <TableCell align="center">2020-02-15</TableCell>
                                    <TableCell align="center">
                                        <CheckCircle variant="contained" style={{color: "green"}} fontSize="large" className={classes.margin}/>
                                        
                                       
                                    </TableCell>

                                </TableRow>


                                <TableRow hover>
                                    <TableCell align="center" component="th" scope="row">

                                        <Button onClick={AbrirD}>1301</Button>
                                    </TableCell>
                                    <TableCell align="center">2020-02-16</TableCell>
                                    <TableCell align="center">

                                        <Cancel variant="contained" style={{ color: "red" }} fontSize="large" className={classes.margin} />

                                    </TableCell>

                                </TableRow >

                                <TableRow hover>
                                    <TableCell align="center" component="th" scope="row">

                                        <Button onClick={AbrirD}>1302</Button>
                                    </TableCell>
                                    <TableCell align="center">2020-02-17</TableCell>
                                    <TableCell align="center">

                                        <CheckCircle variant="contained" style={{ color: "green" }} fontSize="large" className={classes.margin} />

                                    </TableCell>

                                </TableRow>
                                <TableRow hover>
                                    <TableCell align="center" component="th" scope="row">

                                        <Button onClick={AbrirD}>1303</Button>
                                    </TableCell>
                                    <TableCell align="center">2020-02-18</TableCell>
                                    <TableCell align="center">

                                        <HourglassFull variant="contained" style={{ color: "#FFD700" }} fontSize="large" className={classes.margin} />

                                    </TableCell>

                                </TableRow>

                            </TableBody>
                        </Table>
                    </Box>
                </Grid>
            </TableContainer>

            <LevantamientoD open={abrir} fun={AbrirD} />

            <TablePagination
                component="div"
                count={100}
                page={page}
                onChangePage={handleChangePage}
                rowsPerPage={rowsPerPage}
                onChangeRowsPerPage={handleChangeRowsPerPage}
            />
        </Container>
    );
}

export default withRouter(Levantamiento);