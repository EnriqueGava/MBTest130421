 import React from 'react';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import Paper from '@material-ui/core/Paper';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import {withStyles, makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';
import BackIcon from '@material-ui/icons/ArrowBack';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import TextField from '@material-ui/core/TextField';

/* function Copyright() {
  return (
    <Typography variant="body2" color="textSecondary" align="center">
      {'Copyright © '}
      <Link color="inherit" href="https://material-ui.com/">
        Proyecto Metrobus
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
} */
const useStyles = makeStyles((theme) => ({
	root: {
    '& .MuiTextField-root': {
      margin: theme.spacing(1),
      width: '25ch',
    },
  },
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
    
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
  
 formControl: {
		margin: theme.spacing(1),
		minWidth: "75%",
 },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));



export default function Almacen() {
  const classes = useStyles();
  const [age, setAge] = React.useState('');

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  return (
  <div>
	<IconButton edge="start" color="inherit" aria-label="close" href= './Almacen'>
              <BackIcon />
    </IconButton>
    <Container component="main">
      <CssBaseline />
        <div className={classes.paper}>
          <Typography component="h1" variant="h5" align="left">
            Solicitud de Trabajo
          </Typography>
		  
          <form className={classes.form} noValidate>
			<Grid container spacing={2}>
				<Grid item xs={6}>
				 <FormControl required className={classes.formControl}>
					<InputLabel id="demo-simple-select-required-label">Acompañante</InputLabel>
					<Select
					  labelId="demo-simple-select-required-label"
					  id="demo-simple-select-required"
					  //value={age}
					  onChange={handleChange}
					  className={classes.selectEmpty}
					>
					  <MenuItem value="">
						<em>None</em>
					  </MenuItem>
					  <MenuItem value={1}>Abel</MenuItem>
					  <MenuItem value={2}>Enrique</MenuItem>
					  <MenuItem value={3}>Miguel</MenuItem>
					</Select>
					<FormHelperText>Required</FormHelperText>
				 </FormControl>
				</Grid>
				<Grid item xs={6}>
					<FormControl required className={classes.formControl}>
						<InputLabel id="demo-simple-select-required-label">Cuadrilla</InputLabel>
						<Select
						  labelId="demo-simple-select-required-label"
						  id="demo-simple-select-required"
						  //value={age}
						  onChange={handleChange}
						  className={classes.selectEmpty}
						>
						  <MenuItem value="">
							<em>None</em>
						  </MenuItem>
						  <MenuItem value={10}>Cuadrilla #1</MenuItem>
						  <MenuItem value={20}>Cuadrilla #2</MenuItem>
						  <MenuItem value={30}>Cuadrilla #3</MenuItem>
						  <MenuItem value={40}>Cuadrilla #4</MenuItem>
						</Select>
						<FormHelperText>Required</FormHelperText>
					</FormControl>
				</Grid>
				<Grid item xs={12}>
					<FormControl required className={classes.formControl}>
						<InputLabel id="demo-simple-select-required-label">Vehículo</InputLabel>
						<Select
						  labelId="demo-simple-select-required-label"
						  id="demo-simple-select-required"
						  //value={age}
						  onChange={handleChange}
						  className={classes.selectEmpty}
						>
						  <MenuItem value="">
							<em>None</em>
						  </MenuItem>
						  <MenuItem value={10}>Jeep</MenuItem>
						  <MenuItem value={20}>Camioneta 2005</MenuItem>
						  <MenuItem value={30}>Range Rover</MenuItem>
						</Select>
						<FormHelperText>Required</FormHelperText>
					</FormControl>
				</Grid>	
				<Grid item xs={12}>
					<TextField
					  id="outlined-multiline-static"
					  label="Observaciones"
					  multiline
					  fullWidth
					  rows={8}
					  
					  variant="outlined"
					/> 
				</Grid>
			</Grid>
				<Button
				  type="submit"
				  width= "25%"
				  align= "right"
				  variant="contained"
				  color="secondary"
				  className={classes.submit}
				>
				  Finalizar
				</Button>
          </form>
				
            
        </div>
	</Container>
		</div>
  );
}