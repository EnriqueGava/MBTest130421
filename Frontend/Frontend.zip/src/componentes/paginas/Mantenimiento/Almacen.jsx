import React, {useState} from 'react';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import Paper from '@material-ui/core/Paper';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import {withStyles, makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TablePagination from '@material-ui/core/TablePagination';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';
import AddIcon from '@material-ui/icons/Add';
import BackIcon from '@material-ui/icons/ArrowBack';
import Dialog from '@material-ui/core/Dialog';
import ListItemText from '@material-ui/core/ListItemText';
import ListItem from '@material-ui/core/ListItem';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import SearchIcon from '@material-ui/icons/Search';
import SearchInput from './../../SearchInput';
import { TextField } from '@material-ui/core';

/* function Copyright() {
  return (
    <Typography variant="body2" color="textSecondary" align="center">
      {'Copyright © '}
      <Link color="inherit" href="https://material-ui.com/">
        Proyecto Metrobus
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
} */
const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: 4,
    display: 'flex',
    flexDirection: 'column',
    
  },
  
	appBar: {
		position: 'relative',
		backgroundColor: "#4caf50",
	  },
	  
	searchImp: {
		marginTop: theme.spacing(2),
	},   
	title: {
		marginLeft: theme.spacing(2),
		flex: 1,
	}, 
	table: {
		minWidth: "50",
	},
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(3),
	marginRight: theme.spacing(2),
  },
  
  
  formControl: {
	  marginTop: theme.spacing(3),
	marginLeft: theme.spacing(2),
		minWidth: "75%",
 },
 
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
  Modal: {
    position: 'absolute',
    width: 400,
    backgroundColor: theme.palette.background.paper,
    border: '2px solid #000',
    boxShadow: theme.shadows[5],
    padding: theme.spacing(2, 4, 3),
  },
}));

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

function createData( elemento, cantidad) {
  return { elemento, cantidad};
}

const herramienta = [
  createData('Martillo', 1),
  createData('Clavos', 5),
];

const material = [
  createData('Cemento', 30),
  createData('Yeso', 15),
];

function createInv( clave, elemento, cantidad) {
  return { clave, elemento, cantidad};
}

const herramientaInv = [
  createInv('H001', 'Martillo', 50),
  createInv('H002', 'Clavos', 460),
  createInv('H003', 'Tornillo', 70),
  createInv('H004', 'Desarmador', 60),
  createInv('H005', 'Llave 1/4', 40),
  createInv('H006', 'Llave 1/2', 230),
  createInv('H007', 'Llave 3/4', 30),
  createInv('H008', 'Pinza', 40),
];

const materialInv = [
  createInv('M001', 'Cemento', 1234),
  createInv('M002', 'Yeso', 236),
  createInv('M003', 'Vidrio', 567),
  createInv('M004', 'Cal', 123),
  createInv('M005', 'Loza', 2367),
  createInv('M006', 'Tubo PVC 1 1/4', 134),
  createInv('M007', 'Tubo PVC 1', 296),
  
];

const StyledTableCell = withStyles((theme) => ({
  head: {
    backgroundColor: '#9e9e9e',
    color: theme.palette.common.white,
  },
  body: {
    fontSize: 14,
  },
}))(TableCell);


export default function Almacen() {
  const classes = useStyles();
  const [age, setAge] = React.useState('');

  const handleChange = (event) => {
    setAge(event.target.value);
  };
 // const [modalShow, setModalShow] = useState(false);

  const [page, setPage] = React.useState(2);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

 const [open, setOpen] = React.useState(false);
 const [op, setOp] = React.useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleOp = () => {
    setOp(true);
  };
  
  const handleClose = () => {
    setOpen(false);
  };
  
   const handleCl = () => {
    setOp(false);
  };

  const bodyHerr = (
	<div>
        <AppBar className={classes.appBar}>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={handleClose} aria-label="close">
              <CloseIcon />
            </IconButton>
          </Toolbar>
        </AppBar>
		
		<Container className={classes.searchImp}>
			 <SearchInput
              placeholder="Buscar"
            />
            <TableContainer component={Paper}>
                <Grid item xs={6} sm={12}>
                    <Box mr={0}>
                        <Table stickyHeader aria-label="sticky table">
							<TableHead>
							  <TableRow>
								<TableCell >Clave</TableCell>
								<TableCell >Herramienta</TableCell>
								<TableCell >Cantidad</TableCell>
								<TableCell >Existencia</TableCell>
								<TableCell >Agregar</TableCell>
								
							  </TableRow>
							</TableHead>
							<TableBody>
							  {herramientaInv.map((row) => (
								<TableRow key={row.elemento}>
								  <TableCell >{row.clave}</TableCell>
								  <TableCell component="th" scope="row">
									{row.elemento}
								  </TableCell>
								  <TableCell >
									<TextField id="outlined-basic" variant="outlined" size="small" />
								  </TableCell>
								  <TableCell >{row.cantidad}</TableCell>
								  <TableCell >
										<IconButton aria-label="delete">
											<AddIcon />
										</IconButton>
								  </TableCell>
								</TableRow>
							  ))}
							</TableBody>
						</Table>
                    </Box>
                </Grid>
            </TableContainer>

            <TablePagination
                component="div"
                count={100}
                page={page}
                onChangePage={handleChangePage}
                rowsPerPage={rowsPerPage}
                onChangeRowsPerPage={handleChangeRowsPerPage}
            />
        </Container>
    </div>    
  );
  
  const bodyMat = (
	<div>
        <AppBar className={classes.appBar}>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={handleCl} aria-label="close">
              <CloseIcon />
            </IconButton>
          </Toolbar>
        </AppBar>
		
		<Container className={classes.searchImp}>
			<SearchInput
              placeholder="Buscar" 
            />
            <TableContainer component={Paper}>
                <Grid item xs={6} sm={12}>
                    <Box mr={0}>
                        <Table stickyHeader aria-label="sticky table">
							<TableHead>
							  <TableRow>
								<TableCell >Clave</TableCell>
								<TableCell >Material</TableCell>
								<TableCell >Cantidad</TableCell>
								<TableCell >Existencia</TableCell>
								<TableCell >Agregar</TableCell>
							  </TableRow>
							</TableHead>
							<TableBody>
							  {materialInv.map((row) => (
								<TableRow key={row.elemento}>
								  <TableCell >{row.clave}</TableCell>
								  <TableCell component="th" scope="row">
									{row.elemento}
								  </TableCell>
								  <TableCell >
									<TextField id="outlined-basic" variant="outlined" size="small" />
								  </TableCell>
								  <TableCell >{row.cantidad}</TableCell>
								  <TableCell >
										<IconButton aria-label="delete">
											<AddIcon />
										</IconButton>
								  </TableCell>
								</TableRow>
							  ))}
							</TableBody>
						</Table>
                    </Box>
                </Grid>
            </TableContainer>


            <TablePagination
                component="div"
                count={100}
                page={page}
                onChangePage={handleChangePage}
                rowsPerPage={rowsPerPage}
                onChangeRowsPerPage={handleChangeRowsPerPage}
            />
        </Container>
   </div>    
  );

  return (
	  <div>
		  <IconButton edge="start" color="inherit" aria-label="close" href= './MaLevantamiento'>
              <BackIcon />
        </IconButton>
    <Container component="main">
		
      <CssBaseline />
        <div className={classes.paper}>
          <Typography component="h1" variant="h5" align="left">
            ALMACÉN
          </Typography>
          <form className={classes.form} noValidate>
			<Grid container spacing={2}>
			<Grid item xs={3}>
			
			</Grid>
			 <TableContainer component={Paper}>
			  <Table className={classes.table} aria-label="simple table">
				<TableHead>
				  <TableRow>
					<StyledTableCell>Herramienta</StyledTableCell>
					<StyledTableCell align="right">Cantidad</StyledTableCell>
					<StyledTableCell align="right">Eliminar</StyledTableCell>
				  </TableRow>
				</TableHead>
				<TableBody>
				  {herramienta.map((row) => (
					<TableRow key={row.elemento}>
					  <TableCell component="th" scope="row">
						{row.elemento}
					  </TableCell>
					  <TableCell align="right">{row.cantidad}</TableCell>
					  <TableCell align="right">
							<IconButton aria-label="delete">
								<DeleteIcon />
							</IconButton>
					  </TableCell>
					</TableRow>
				  ))}
				</TableBody>
			  </Table>
			</TableContainer>
			  <Button
				  //type="submit"
				  fullWidth
				  variant="contained"
				  color="secondary"
				  className={classes.submit}
				   onClick={handleOpen}
				>
				  Agregar Herramienta
				</Button>
				 
			 <TableContainer component={Paper}>
			  <Table className={classes.table} aria-label="simple table">
				<TableHead>
				  <TableRow>
					<StyledTableCell>Material</StyledTableCell>
					<StyledTableCell align="right">Cantidad</StyledTableCell>
					<StyledTableCell align="right">Eliminar</StyledTableCell>
				  </TableRow>
				</TableHead>
				<TableBody>
				  {material.map((row) => (
					<TableRow key={row.name}>
					  <TableCell component="th" scope="row">
						{row.elemento}
					  </TableCell>
					  <TableCell align="right">{row.cantidad}</TableCell>
					  <TableCell align="right">
							<IconButton aria-label="delete">
								<DeleteIcon />
							</IconButton>
					  </TableCell>
					</TableRow>
				  ))}
				</TableBody>
			  </Table>
			</TableContainer>
				<Button
				  //type="submit"
				  fullWidth
				  variant="contained"
				  color="secondary"
				  className={classes.submit}
				   onClick={handleOp}
				>
				  Agregar Material
				</Button>
				
           </Grid>
		   <Dialog
				fullScreen open={open}
				onClose={handleClose}
				TransitionComponent={Transition}
			  >
				{bodyHerr}
			  </Dialog>
			  
			  <Dialog
				fullScreen open={op}
				onClose={handleCl}
				TransitionComponent={Transition}
			  >
				{bodyMat}
			  </Dialog>
				<Button
				  type="submit"
				  href= './STrabajo'
				  width= "25%"
				  align= "right"
				  variant="contained"
				  color="secondary"
				  className={classes.submit}>
				  Siguiente
				</Button>
          </form>
				
            
        </div>
	</Container>	
	</div>
  );
}