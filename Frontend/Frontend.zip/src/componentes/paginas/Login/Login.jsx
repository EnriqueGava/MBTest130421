import React, { useRef, Component } from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Paper from '@material-ui/core/Paper';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import TrainIcon from '@material-ui/icons/TrainOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import pic1 from '../image/mb1.jpg'
import pic2 from '../image/mb2.jpg'
import pic3 from '../image/mb3.jpg'
import pic4 from '../image/mb4.jpg'
import Container from './../../SideBar/Container';
import ContainerM from './../../SideBar//SideBarM/ContainerM';
import {login} from './UserFunctions'
import App from '../../../App'
import axios from 'axios'
function Copyright() {
  return (
    <Typography variant="body2" color="textSecondary" align="center">
      {'Copyright © '}
      <Link color="inherit" href="https://material-ui.com/">
        Proyecto Metrobus
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

const pictureArray = [pic1, pic2, pic3, pic4];
const randomIndex = Math.floor(Math.random() * pictureArray.length);
const selectedPicture = pictureArray[randomIndex];
const useStyles = makeStyles((theme) => ({
  root: {
    height: '100vh',
  },
  
    
  image: {
	backgroundImage: `url(${selectedPicture})`, //'url(https://source.unsplash.com/random)',
    backgroundRepeat: 'no-repeat',
    backgroundColor:
      theme.palette.type === 'light' ? theme.palette.grey[50] : theme.palette.grey[900],
    backgroundSize: 'cover',
    backgroundPosition: 'center',
  },
  paper: {
    margin: theme.spacing(8, 4),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(1),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

export default function SignInSide() {
  const classes = useStyles();

  const emailRef = useRef('') //creating a refernce for TextField Component
  const passRef = useRef('') //creating a refernce for TextField Component

  const [datos,setDatos] = React.useState({
    email: '',
    password: ''
  });
  const [response, setResponse] = React.useState({});
  const [flag, setFlag] = React.useState(true)

  
  const handleInput = (event) => {
    setDatos({
      ...datos,
      [event.target.name] : event.target.value
    })

    console.log(datos)
  }

  const onSumit = e => {
    axios
    .post('http://localhost:5000/auth', {
      email: datos.email,
      password: datos.password
    })
    .then(response => {
      console.log(response.data)
      localStorage.setItem('usertoken', response.data)
      
    })
    .catch(err => {
      console.log('Contraseña y Usuarios no validos , ' + err)
    })
  }
  
  if(flag)
  return (
    <Grid container component="main" className={classes.root}>
      <CssBaseline />
      <Grid item xs={false} sm={4} md={7} className={classes.image} />
      <Grid item xs={12} sm={8} md={5} component={Paper} elevation={6} square>
        <div className={classes.paper}>
          <Avatar className={classes.avatar}>
            <TrainIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            Entrar
          </Typography>
          <form className={classes.form} noValidate 
                onSubmit={() => onSumit()}>
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="email"
              label="Usuario"
              name="email"
              autoComplete="email"
              autoFocus
              inputRef={emailRef}  
              onChange={handleInput} 
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              name="password"
              label="Contraseña"
              type="password"
              id="password" 
              autoComplete="current-password" 
              onChange={handleInput}
            />
            <FormControlLabel
              control={<Checkbox value="remember" color="primary" />}
              label="Recuerdame"
            />

            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="secondary"
              className={classes.submit}
            >
              Ingresar
            </Button>

            <Grid container>
              <Grid item xs>
                <Link href="/RecuperarC" variant="body2">
                  Recuperar Contraseña.
                </Link>
              </Grid>

              <Grid item>
                <Link href="/SignUp" variant="body2">
                  {"No tienes cuenta? Registrate"}
                </Link>
              </Grid>

            </Grid>
            <Box mt={5}>
              <Copyright />
            </Box>
          </form>
        </div>
      </Grid>
    </Grid>
    
  );
  else
    return <App role={2}/>
  
}