import React from 'react';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import Paper from '@material-ui/core/Paper';
import Box from '@material-ui/core/Box';
import {
    Grid,
    GridList,
    GridListTile,
    DialogTitle,
    DialogContent,
    DialogActions

}from '@material-ui/core';
import Typography from '@material-ui/core/Typography';
import {withStyles, makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import TextField from '@material-ui/core/TextField';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import CloseIcon from '@material-ui/icons/Close';
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import { red, green } from '@material-ui/core/colors';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { Table, TablePagination} from '@material-ui/core';
import ImageIcon from '@material-ui/icons/Image';
import {DropzoneArea} from 'material-ui-dropzone';
const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(8),
    display: 'flex',
    flexDirection: 'column',
     padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    
  },
  
  margin: {
    margin: theme.spacing(2),
  },
  gridList: {
	flexWrap: 'nowrap',
	// Promote the list into his own layer on Chrome. This cost memory but helps keeping high FPS.
	transform: 'translateZ(0)',
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
  
 formControl: {
		margin: theme.spacing(1),
		minWidth: "75%",
 },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
    appBar: {
		position: 'relative',
		backgroundColor: "#4caf50",
	  },
    table: {
        minWidth: 50
    },
        boton2: {
        color: theme.palette.getContrastText(green[700]),
        backgroundColor: green[700],
        '&:hover': {
            backgroundColor: green[700],
        },
    },
    dialogf: {
        backgroundColor: "#f4f6f8",
    }
}));
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function Nue() {
  const classes = useStyles();
  const [age, setAge] = React.useState('');

  const handleChange = (event) => {
    setAge(event.target.value);
  };
const [open, setOpen] = React.useState(false);
 const [op, setOp] = React.useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleOp = () => {
    setOp(true);
  };
  
  const handleClose = () => {
    setOpen(false);
  };
  
   const handleCl = () => {
    setOp(false);
  };


    
    const [page, setPage] = React.useState(2);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);

        const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };
    

  const bodyElem = (
	
        <Container>  
          <Dialog fullScreen open={open} onClose={handleClose} classes={{paper: classes.dialogf}}>
        <AppBar className={classes.appBar}>
          <Toolbar>
            <IconButton autoFocusedge="start" color="inherit" onClick={handleClose} aria-label="close">
              <CloseIcon />
            </IconButton>
            <Typography variant="h6" className={classes.title}>
              
            </Typography>
           
          </Toolbar>
        </AppBar>
      <Container>  
		<Grid container spacing={2}>
				<Grid item xs={12}>
					<TextField id="outlined-basic" label="Clave"  size="small" variant="outlined" className={classes.margin}
					  onChange={handleChange}/>
					<Button variant="contained" color="primary" size="medium" className={classes.margin}
					//onclick={setAge(11)}
					>
					  Buscar
					</Button>
				</Grid>
				<Grid item xs={6}>
				 <FormControl required className={classes.formControl}>
					<InputLabel id="demo-simple-select-required-label">Categorias</InputLabel>
					<Select
					  labelId="demo-simple-select-required-label"
					  id="Catego"
					  value={age}
					  onChange={handleChange}
					  className={classes.selectEmpty}
					  
					>
					  <MenuItem value="">
						<em>None</em>
					  </MenuItem>
					  <MenuItem value={11}>Plazoleta</MenuItem>
					  <MenuItem value={12}>Rampa de acceso a estacion</MenuItem>
					  <MenuItem value={13}>Anden /Plataforma </MenuItem>
					</Select>
				 </FormControl>
				</Grid>
				
            <Grid item xs={6}>
					<FormControl required className={classes.formControl}>
						<InputLabel id="demo-simple-select-required-label">Concepto</InputLabel>
						<Select
						  labelId="demo-simple-select-required-label"
						  id="demo-simple-select-required"
						  value={age}
						  onChange={handleChange}
						  className={classes.selectEmpty}
						  fullWidth
						>
						  
						  <MenuItem value={11}>Bolardos de confinamiento peatonal</MenuItem>
                          <MenuItem value={12}>Bolardos de confinamiento peatonal</MenuItem>
						</Select>
						
					</FormControl>
				</Grid>
       
            <Grid item xs={6}>
					<FormControl required className={classes.formControl}>
						<InputLabel id="demo-simple-select-required-label">Falla</InputLabel>
						<Select
						  labelId="demo-simple-select-required-label"
						  id="demo-simple-select-required"
						  value={age}
						  onChange={handleChange}
						  className={classes.selectEmpty}
						  fullWidth
						>
						  
						  <MenuItem value={11}>Ausente </MenuItem>
                        <MenuItem value={12}>Fracura</MenuItem>
						</Select>
						
					</FormControl>
				</Grid>
    
                 <Container >
                    <DropzoneArea acceptedFiles={['image/*']}
                    dropzoneText={"Arrasta la imagen o da click aqui"}/>
                    <Box display="flex" justifyContent="flex-end" mt={1}>
                    <Button variant="contained" component="label" className={classes.boton2}>
                    Aceptar   
                    </Button>
                    </Box>
                    </Container> 
                               
                        
         
         
				      
      
			</Grid>
             </Container>  
            
       </Dialog>
        </Container>  
  );
    

  
    
  return (
    
     <Container component="main">
      <CssBaseline />
        <div className={classes.paper}>
          <Typography component="h1" variant="h5" align="left">
            Nuevo levantamiento
          </Typography>
          <form className={classes.form} noValidate>
			<Grid container spacing={2}>
				<Grid item xs={6}>
				 <FormControl required className={classes.formControl}>
					<InputLabel id="demo-simple-select-required-label">Linea</InputLabel>
					<Select
					  labelId="demo-simple-select-required-label"
					  id="demo-simple-select-required"
					  //value={age}
					  onChange={handleChange}
					  className={classes.selectEmpty}
					>
					  <MenuItem value="">
						<em>None</em>
					  </MenuItem>
					  <MenuItem value={1}>Linea 1</MenuItem>
					  <MenuItem value={2}>Linea 2</MenuItem>
					  <MenuItem value={3}>Linea 3</MenuItem>
					</Select>
					<FormHelperText>Required</FormHelperText>
				 </FormControl>
				</Grid>
				<Grid item xs={6}>
					<FormControl required className={classes.formControl}>
						<InputLabel id="demo-simple-select-required-label">Estaciones</InputLabel>
						<Select
						  labelId="demo-simple-select-required-label"
						  id="demo-simple-select-required"
						  //value={age}
						  onChange={handleChange}
						  className={classes.selectEmpty}
						>
						  <MenuItem value="">
							<em>None</em>
						  </MenuItem>
						  <MenuItem value={10}>Indios verdes </MenuItem>
						  <MenuItem value={20}>Deportivo 18 de marzo</MenuItem>
						  <MenuItem value={30}>Euzkaro</MenuItem>
						  <MenuItem value={40}>Potrero</MenuItem>
						</Select>
						<FormHelperText>Required</FormHelperText>
					</FormControl>
				</Grid>
				<Grid item xs={6}>
					<FormControl required className={classes.formControl}>
						<InputLabel id="demo-simple-select-required-label">Sentido</InputLabel>
						<Select
						  labelId="demo-simple-select-required-label"
						  id="demo-simple-select-required"
						  //value={age}
						  onChange={handleChange}
						  className={classes.selectEmpty}
						>
						  <MenuItem value="">
							<em>None</em>
						  </MenuItem>
						  <MenuItem value={10}>Norte-Sur</MenuItem>
                          <MenuItem value={20}>Sur-Norte</MenuItem>
						</Select>
						<FormHelperText>Required</FormHelperText>
					</FormControl>
				</Grid>
                <Grid item xs={12}>
                
				 
                      <Button  onClick={handleOpen} fullWidth variant="contained" component="label" className={classes.boton2}>
				  Agregar Elementos
				</Button>
                    </Grid>
                </Grid>
               <Dialog
				fullScreen open={open}
				onClose={handleClose}
				TransitionComponent={Transition}
			  >
				{bodyElem}
			  </Dialog>
              
			<Box mr={0}>
                    <TableContainer component={Paper}>
                        <Table stickyHeader aria-label="sticky table">
                            <TableHead>
                                <TableRow hover>
                                    <TableCell>Clave</TableCell>
                                    <TableCell align="center">Categoria</TableCell>
                                    <TableCell align="center">Concepto</TableCell>
                                    <TableCell align="center">Falla</TableCell>
                                     <TableCell align="center">Foto de la falla</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>

                                <TableRow hover>
                                    
                                    <TableCell align="center">L1-PL-20</TableCell>
                                    <TableCell align="center">ANDÉN / PLATAFORMA</TableCell>
                                    <TableCell align="center">Extintores</TableCell>
                                    <TableCell align="center">Fractura</TableCell>
                                    <TableCell align="center">
                                     <Button  onClick={handleOp}><ImageIcon fontSize="large" /></Button>
                                    </TableCell>
                                </TableRow>

                            </TableBody>
                        </Table>
                    </TableContainer>
                    <TablePagination
            component="div"
            count={100}
            page={page}
            onChangePage={handleChangePage}
            rowsPerPage={rowsPerPage}
            onChangeRowsPerPage={handleChangeRowsPerPage}
        />
                </Box>	
				<Dialog onClose={handleCl} aria-labelledby="customized-dialog-title" open={op}>
                <DialogTitle id="customized-dialog-title" onClose={handleCl}>
                    Fotos de las Fallas
                </DialogTitle>
                <DialogContent dividers>
                    <GridList className={classes.gridList} cellHeight={500} cols={2}>
                        <GridListTile>
                            <img src="/images/logos/Extintor.png" width="100" height="500" />
                        </GridListTile>
                        <GridListTile>
                            <img src="/images/logos/Extintor.png" width="100" height="500" />
                        </GridListTile>
                        <GridListTile>
                            <img src="/images/logos/Extintor.png" width="100" height="500" />
                        </GridListTile>
                    </GridList>
                </DialogContent>
                  <DialogActions>
                    <Button autoFocus onClick={handleCl} color="primary">
                        Cerrar
          </Button>
                </DialogActions>
            </Dialog>

			  
             <Button variant="contained" component="label" className={classes.boton2}>
				  Generar
				</Button>
          </form>   
        </div>
      
	</Container>	
  );
    
    
}
